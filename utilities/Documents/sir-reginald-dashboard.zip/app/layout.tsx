import type React from "react"
import type { Metadata, Viewport } from "next"
import { Inter } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Sir Reginald - Workshop Safety Guardian",
  description: "Your Distinguished Workshop Guardian - Real-time AI safety monitoring for your workshop",
    generator: 'v0.app'
}

export const viewport: Viewport = {
  themeColor: "#0F0F0F",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
